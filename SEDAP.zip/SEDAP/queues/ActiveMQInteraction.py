# queue parameters


def send_message_to_error_queue(entry):
    # write code to send message