import os

def read_file(file_path):
    if os.path.exists(file_path):
        # start file open
        # for loop -
            # for each Record -divide entries
            # for eachValue in eachEntry
                # validations


def processErrors():
