class CustomerValidation:

    def entryIdValidation(self, entryId):
        # logic for validation
        # return errorMessage