

def read_customer_watch_time():
    print("This is where program will start")
    list_cwt = [[1, 'Rishi', 35, 1200, '1300', 1400],
                [2, 'Anand', 40, 1521, '0100', 1400], ]
    return list_cwt