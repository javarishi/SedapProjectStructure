def create_connection():
    print("MySQL Installation and Connection")


def create_activemq_connection():
    print("ActiveMQ Connection")